def main():
    print("this is the cli")